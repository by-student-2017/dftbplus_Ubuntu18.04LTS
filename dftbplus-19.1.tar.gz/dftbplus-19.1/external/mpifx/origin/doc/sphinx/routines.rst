.. _sec_routines:

List of routines
================

You can generate the list and the description of the MPIFX routines via doxygen
(see folder `doc/doxygen/` in the source tree) or sphinx.
