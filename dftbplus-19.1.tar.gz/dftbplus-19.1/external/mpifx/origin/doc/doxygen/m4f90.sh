#!/bin/sh
m4 -I$(dirname $1) $1
