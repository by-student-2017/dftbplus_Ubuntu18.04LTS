Compiler workarounds
====================

minimal (non-) working examples for compilers and computing environments. These
should contain a note of the case for which it fails, and if possible a viable
work-around.
