Generate charges for a good k-point set and read back in for a band structure
calculation.
