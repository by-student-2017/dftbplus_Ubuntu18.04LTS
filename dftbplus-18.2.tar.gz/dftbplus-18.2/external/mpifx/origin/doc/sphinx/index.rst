Welcome to MPIFX's documentation!
=================================

.. toctree::
   :maxdepth: 1

   about.rst
   installing.rst
   using.rst
   routines.rst
   license.rst

